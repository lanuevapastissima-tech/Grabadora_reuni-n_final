import "dotenv/config";
import express from "express";
import { createServer as createViteServer } from "vite";
import multer from "multer";
import OpenAI from "openai";
import fs from "fs";
import path from "path";

// Initialize OpenAI
const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
});

const storage = multer.memoryStorage();
const upload = multer({ 
  storage: storage,
  limits: { fileSize: 50 * 1024 * 1024 } // 50MB
});

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json({ limit: '50mb' }));
  app.use(express.urlencoded({ limit: '50mb', extended: true }));

  app.get("/api/health", (req, res) => {
    res.json({ status: "ok", env: process.env.NODE_ENV });
  });

  // Request logging
  app.use((req, res, next) => {
    console.log(`${req.method} ${req.url}`);
    next();
  });

  // API routes FIRST
  app.post("/api/summarize", upload.single("audio"), async (req, res) => {
    try {
      if (!req.file) {
        return res.status(400).json({ error: "No audio file provided" });
      }

      // 1. Transcribe with Whisper
      const transcription = await openai.audio.transcriptions.create({
        file: await OpenAI.toFile(req.file.buffer, req.file.originalname),
        model: "whisper-1",
        language: "es",
      });

      const transcriptText = transcription.text;

      if (!transcriptText) {
        return res.status(500).json({ error: "Transcription failed" });
      }

      // 2. Summarize with GPT-4o-mini
      const { date, time, lugar } = req.body;

      const summarySchema = {
        type: "object",
        properties: {
            fechaReunion: { type: "string", description: 'La fecha de la reunión, si se menciona.' },
            horaReunion: { type: "string", description: 'La hora de la reunión en formato HH:MM.' },
            lugar: { type: "string", description: 'El lugar (físico o virtual) de la reunión.' },
            asistentes: { type: "array", items: { type: "string" }, description: 'Lista de nombres de los asistentes mencionados.' },
            resumenEjecutivo: { type: "string", description: 'Un resumen ejecutivo conciso de la reunión.' },
            temasTratados: { type: "array", items: { type: "string" }, description: 'Una lista de los principales temas discutidos.' },
            acuerdosAlcanzados: { type: "array", items: { type: "string" }, description: 'Una lista de los acuerdos y decisiones tomadas.' },
            proximosPasos: { type: "array", items: { type: "string" }, description: 'Una lista de las acciones o próximos pasos a seguir.' },
            conclusiones: { type: "string", description: 'Las conclusiones generales de la reunión.' }
        },
        required: ["fechaReunion", "horaReunion", "lugar", "asistentes", "resumenEjecutivo", "temasTratados", "acuerdosAlcanzados", "proximosPasos", "conclusiones"],
        additionalProperties: false
      };

      const summaryPrompt = `
      Basado en la siguiente transcripción de una reunión, y usando el contexto proporcionado, completa todos los campos del JSON solicitado de manera precisa y profesional en español.

      Contexto de la reunión:
      - Fecha: ${date}
      - Hora: ${time}
      - Lugar: ${lugar || 'No especificado'}

      Transcripción:
      ---
      ${transcriptText}
      ---
      `;

      const completion = await openai.chat.completions.create({
        model: "gpt-4o-mini",
        messages: [
          { role: "system", content: "Eres un asistente experto en analizar transcripciones de reuniones y estructurar la información clave." },
          { role: "user", content: summaryPrompt }
        ],
        response_format: {
          type: "json_schema",
          json_schema: {
            name: "summary_schema",
            schema: summarySchema,
            strict: true
          }
        }
      });

      const summaryJson = JSON.parse(completion.choices[0].message.content || "{}");

      res.json({ summary: summaryJson, transcript: transcriptText });

    } catch (error: any) {
      console.error("Error in /api/summarize:");
      console.error(error);
      if (error.response) {
        console.error("Response data:", error.response.data);
      }
      res.status(500).json({ error: error.message || "Internal server error" });
    }
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });

  // Global error handler
  app.use((err: any, req: express.Request, res: express.Response, next: express.NextFunction) => {
    console.error("Global error handler caught:", err);
    res.status(500).json({ error: err.message || "Internal server error" });
  });
}

startServer();
