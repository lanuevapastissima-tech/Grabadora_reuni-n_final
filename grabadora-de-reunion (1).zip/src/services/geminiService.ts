import { GoogleGenAI } from "@google/genai";

let manualApiKey: string | null = localStorage.getItem('GEMINI_MANUAL_API_KEY');

export const setManualApiKey = (key: string | null) => {
  manualApiKey = key;
  if (key) {
    localStorage.setItem('GEMINI_MANUAL_API_KEY', key);
  } else {
    localStorage.removeItem('GEMINI_MANUAL_API_KEY');
  }
};

export const getManualApiKey = () => manualApiKey;

export const getGeminiInstance = () => {
  const key = manualApiKey || (process.env as any).API_KEY || (process.env as any).GEMINI_API_KEY;
  if (!key) {
    throw new Error("API_KEY_MISSING");
  }
  return new GoogleGenAI({ apiKey: key });
};
