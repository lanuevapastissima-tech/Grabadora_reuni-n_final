import { GoogleGenAI } from "@google/genai";

let manualApiKey: string | null = localStorage.getItem('manual_gemini_api_key');

export const setManualApiKey = (key: string | null) => {
    manualApiKey = key;
    if (key) {
        localStorage.setItem('manual_gemini_api_key', key);
    } else {
        localStorage.removeItem('manual_gemini_api_key');
    }
};

export const getGeminiInstance = () => {
    const apiKey = manualApiKey || process.env.API_KEY || process.env.GEMINI_API_KEY;
    
    if (!apiKey || apiKey === 'AI Studio Free Tier') {
        throw new Error('AUTH_ERROR: No se encontró una clave de API válida.');
    }

    return new GoogleGenAI({ apiKey });
};
