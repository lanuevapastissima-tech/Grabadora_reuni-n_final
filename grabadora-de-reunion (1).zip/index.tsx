import React, { useState, useRef, useEffect, useCallback } from 'react';
import ReactDOM from 'react-dom/client';
import { getGeminiInstance, setManualApiKey } from './src/gemini';
import { Type } from "@google/genai";

declare global {
    interface Window {
        aistudio: {
            hasSelectedApiKey: () => Promise<boolean>;
            openSelectKey: () => Promise<void>;
        };
        jspdf: any;
    }
}

// Tipos de datos
type Summary = {
  fechaReunion: string;
  horaReunion: string;
  lugar: string;
  asistentes: string[];
  resumenEjecutivo: string;
  temasTratados: string[];
  acuerdosAlcanzados: string[];
  proximosPasos: string[];
  conclusiones: string;
};

type Recording = {
  id: string;
  name: string;
  blobUrl: string;
  blob: Blob;
  date: Date;
  duration: number;
  lugar?: string;
  summary?: Summary | null;
  attendeesPhoto?: string; // base64 string
};

// Utilidad para convertir AudioBuffer a WAV Blob (8kHz Mono para ahorrar espacio)
function audioBufferToWav(buffer: AudioBuffer): Blob {
  const numOfChan = 1; // Mono
  const length = buffer.length * numOfChan * 2 + 44;
  const bufferArr = new ArrayBuffer(length);
  const view = new DataView(bufferArr);
  const channels = [];
  let i;
  let sample;
  let offset = 0;
  let pos = 0;

  // Escribir cabecera WAVE
  setUint32(0x46464952);                         // "RIFF"
  setUint32(36 + buffer.length * 2);             // file length - 8
  setUint32(0x45564157);                         // "WAVE"
  setUint32(0x20746d66);                         // "fmt " chunk
  setUint32(16);                                 // length = 16
  setUint16(1);                                  // PCM (uncompressed)
  setUint16(numOfChan);
  setUint32(buffer.sampleRate);
  setUint32(buffer.sampleRate * 2 * numOfChan);  // avg. bytes/sec
  setUint16(2 * numOfChan);                      // block-align
  setUint16(16);                                 // 16-bit

  setUint32(0x61746164);                         // "data" - chunk
  setUint32(buffer.length * 2);                  // chunk length

  // Escribir datos
  const inputData = buffer.getChannelData(0); // Tomar canal 0 (mono)
  
  for (i = 0; i < buffer.length; i++) {
     let s = Math.max(-1, Math.min(1, inputData[i]));
     s = s < 0 ? s * 0x8000 : s * 0x7FFF;
     view.setInt16(pos, s, true);
     pos += 2;
  }

  function setUint16(data: number) {
    view.setUint16(pos, data, true);
    pos += 2;
  }

  function setUint32(data: number) {
    view.setUint32(pos, data, true);
    pos += 4;
  }

  return new Blob([bufferArr], { type: 'audio/wav' });
}

// Función para procesar y optimizar audio (extraer de video, bajar sample rate)
async function processAudioFile(file: File): Promise<Blob> {
    const arrayBuffer = await file.arrayBuffer();
    const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
    const audioContext = new AudioContextClass();
    
    const audioBuffer = await new Promise<AudioBuffer>((resolve, reject) => {
        audioContext.decodeAudioData(arrayBuffer, resolve, reject);
    });
    
    // Resamplear a 16000Hz (Calidad de voz estándar, excelente para transcripción)
    const targetSampleRate = 16000; 
    
    const OfflineAudioContextClass = window.OfflineAudioContext || (window as any).webkitOfflineAudioContext;
    const offlineCtx = new OfflineAudioContextClass(1, audioBuffer.duration * targetSampleRate, targetSampleRate);
    const source = offlineCtx.createBufferSource();
    source.buffer = audioBuffer;
    source.connect(offlineCtx.destination);
    source.start();
    
    const resampledBuffer = await new Promise<AudioBuffer>((resolve, reject) => {
        offlineCtx.oncomplete = (e) => resolve(e.renderedBuffer);
        // offlineCtx.onerror no siempre está disponible, pero startRendering puede fallar
        try {
            const renderPromise = offlineCtx.startRendering();
            if (renderPromise) {
                renderPromise.catch(reject);
            }
        } catch (err) {
            reject(err);
        }
    });
    
    return audioBufferToWav(resampledBuffer);
}

// Componente principal de la aplicación
const App = () => {
    const [isRecording, setIsRecording] = useState(false);
    const [elapsedTime, setElapsedTime] = useState(0);
    const [recordings, setRecordings] = useState<Recording[]>([]);
    const [currentSummary, setCurrentSummary] = useState<Summary | null>(null);
    const [editableSummary, setEditableSummary] = useState<Summary | null>(null);
    const [isEditingSummary, setIsEditingSummary] = useState(false);
    const [isLoadingSummary, setIsLoadingSummary] = useState(false);
    const [processingStatus, setProcessingStatus] = useState<string>("");
    const [error, setError] = useState<string | null>(null);
    const [isAuthError, setIsAuthError] = useState(false);
    const [showApiKeyInput, setShowApiKeyInput] = useState(false);
    const [manualApiKey, setManualApiKeyState] = useState(localStorage.getItem('manual_gemini_api_key') || '');
    const [editingRecordingId, setEditingRecordingId] = useState<string | null>(null);
    const [editingRecordingData, setEditingRecordingData] = useState<Partial<Recording>>({});
    const [logo, setLogo] = useState<string | null>(null);
    const [activeRecording, setActiveRecording] = useState<Recording | null>(null);
    const [theme, setTheme] = useState('dark');
    const [recordingIdForPhoto, setRecordingIdForPhoto] = useState<string | null>(null);
    const [recordingToDeleteId, setRecordingToDeleteId] = useState<string | null>(null);
    const [canShare, setCanShare] = useState(false);


    const mediaRecorderRef = useRef<MediaRecorder | null>(null);
    const audioChunksRef = useRef<Blob[]>([]);
    const timerIntervalRef = useRef<number | null>(null);
    const fileInputRef = useRef<HTMLInputElement>(null);
    const photoInputRef = useRef<HTMLInputElement>(null);
    const uploadInputRef = useRef<HTMLInputElement>(null);


    useEffect(() => {
        const savedLogo = localStorage.getItem('companyLogo');
        if (savedLogo) {
            setLogo(savedLogo);
        }
        const savedTheme = localStorage.getItem('theme') || 'dark';
        setTheme(savedTheme);
        document.body.className = `${savedTheme}-theme`;

        if (navigator.share && typeof navigator.canShare === 'function') {
            const dummyFile = new File([""], "dummy.pdf", { type: "application/pdf" });
            if (navigator.canShare({ files: [dummyFile] })) {
                setCanShare(true);
            }
        }
    }, []);

    const toggleTheme = () => {
        const newTheme = theme === 'dark' ? 'light' : 'dark';
        setTheme(newTheme);
        localStorage.setItem('theme', newTheme);
        document.body.className = `${newTheme}-theme`;
    };

    const formatTime = (totalSeconds: number): string => {
        const hours = Math.floor(totalSeconds / 3600);
        const minutes = Math.floor((totalSeconds % 3600) / 60);
        const seconds = totalSeconds % 60;
        return [hours, minutes, seconds]
            .map(v => v.toString().padStart(2, '0'))
            .join(':');
    };
    
    const stopTimer = () => {
        if (timerIntervalRef.current) {
            clearInterval(timerIntervalRef.current);
            timerIntervalRef.current = null;
        }
    };

    const startTimer = () => {
        stopTimer();
        setElapsedTime(0);
        timerIntervalRef.current = window.setInterval(() => {
            setElapsedTime(prev => prev + 1);
        }, 1000);
    };

    const handleStopRecording = useCallback(() => {
        if (mediaRecorderRef.current && mediaRecorderRef.current.state === 'recording') {
            mediaRecorderRef.current.stop();
        }
    }, []);

    const startRecording = async () => {
        try {
            const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
            setIsRecording(true);
            startTimer();
            audioChunksRef.current = [];
            
            let options: MediaRecorderOptions = {};
            if (MediaRecorder.isTypeSupported('audio/webm;codecs=opus')) {
                options = { mimeType: 'audio/webm;codecs=opus', audioBitsPerSecond: 16000 };
            } else if (MediaRecorder.isTypeSupported('audio/mp4')) {
                options = { mimeType: 'audio/mp4', audioBitsPerSecond: 16000 };
            }
            
            const mediaRecorder = new MediaRecorder(stream, options);
            mediaRecorderRef.current = mediaRecorder;

            mediaRecorder.ondataavailable = (event) => {
                audioChunksRef.current.push(event.data);
            };

            mediaRecorder.onstop = () => {
                const audioBlob = new Blob(audioChunksRef.current, { type: mediaRecorder.mimeType || 'audio/webm' });
                const blobUrl = URL.createObjectURL(audioBlob);
                const newRecording: Recording = {
                    id: `rec-${Date.now()}`,
                    name: `Grabación ${recordings.length + 1}`,
                    blobUrl,
                    blob: audioBlob,
                    date: new Date(),
                    duration: elapsedTime,
                    lugar: '',
                    summary: null
                };
                setRecordings(prev => [newRecording, ...prev].sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime()));
                setIsRecording(false);
                stopTimer();
                stream.getTracks().forEach(track => track.stop());
            };

            mediaRecorder.start();
        } catch (err) {
            console.error("Error al acceder al micrófono:", err);
            setError("No se pudo acceder al micrófono. Por favor, revisa los permisos en tu navegador.");
        }
    };
    
    const handleRestartTimer = () => {
        setElapsedTime(0);
    };

    // Funcionalidad para subir audio existente
    const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
        const file = e.target.files?.[0];
        if (!file) return;

        // Validar tipos de archivo: audio/*, video/mp4, video/mpeg, etc.
        const isAudio = file.type.startsWith('audio/');
        const isVideo = file.type.startsWith('video/');
        const nameLower = file.name.toLowerCase();
        const hasValidExtension = nameLower.endsWith('.mp4') || nameLower.endsWith('.m4a') || nameLower.endsWith('.mp3') || nameLower.endsWith('.wav') || nameLower.endsWith('.ogg') || nameLower.endsWith('.flac');

        if (!isAudio && !isVideo && !hasValidExtension) {
            setError("Por favor, selecciona un archivo de audio o video válido (ej. .mp3, .wav, .mp4, .m4a).");
            return;
        }
        setError(null);

        const blobUrl = URL.createObjectURL(file);
        const audio = new Audio(blobUrl);
        
        audio.onloadedmetadata = () => {
             addUploadedRecording(file, blobUrl, audio.duration);
        };
        
        audio.onerror = () => {
             addUploadedRecording(file, blobUrl, 0);
        };
    };

    const addUploadedRecording = (file: File, blobUrl: string, duration: number) => {
         const newRecording: Recording = {
            id: `rec-${Date.now()}`,
            name: file.name.replace(/\.[^/.]+$/, ""),
            blobUrl,
            blob: file,
            date: new Date(file.lastModified),
            duration: Math.floor(duration),
            lugar: 'Archivo Importado',
            summary: null
        };
        setRecordings(prev => [newRecording, ...prev].sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime()));
        if (uploadInputRef.current) uploadInputRef.current.value = '';
    };

    const blobToBase64 = (blob: Blob): Promise<string> => {
        return new Promise((resolve, reject) => {
            const reader = new FileReader();
            reader.onloadend = () => {
                const base64String = (reader.result as string).split(',')[1];
                resolve(base64String);
            };
            reader.onerror = reject;
            reader.readAsDataURL(blob);
        });
    }
    
    const fileToBase64 = (file: File): Promise<string> => {
        return new Promise((resolve, reject) => {
            const reader = new FileReader();
            reader.onloadend = () => {
                resolve(reader.result as string);
            };
            reader.onerror = reject;
            reader.readAsDataURL(file);
        });
    }

    const handleConfigureKey = async () => {
        try {
            if (window.aistudio && typeof window.aistudio.openSelectKey === 'function') {
                await window.aistudio.openSelectKey();
                // Asumimos que si se abrió el selector, el usuario lo gestionará
                setError(null);
                setIsAuthError(false);
            } else {
                setShowApiKeyInput(true);
            }
        } catch (e) {
            console.error("Error al abrir selector de claves:", e);
            setShowApiKeyInput(true);
        }
    };

    const handleSaveManualKey = () => {
        if (manualApiKey.trim()) {
            setManualApiKey(manualApiKey.trim());
            setError(null);
            setIsAuthError(false);
            setShowApiKeyInput(false);
        }
    };

    const generateSummary = async (recording: Recording) => {
        setIsLoadingSummary(true);
        setActiveRecording(recording);
        setCurrentSummary(null);
        setError(null);
        setIsAuthError(false);
        setProcessingStatus("Analizando con Gemini...");

        try {
            const ai = await getGeminiInstance();
            
            const audioBase64 = await blobToBase64(recording.blob);
            
            const prompt = `
            Basado en el audio de la reunión adjunto, y usando el contexto proporcionado, genera un resumen ejecutivo profesional en español.
            
            Contexto de la reunión:
            - Fecha: ${new Date(recording.date).toLocaleDateString('es-ES')}
            - Hora: ${new Date(recording.date).toLocaleTimeString('es-ES', { hour: '2-digit', minute: '2-digit' })}
            - Lugar: ${recording.lugar || 'No especificado'}
            
            Responde ÚNICAMENTE con un objeto JSON que siga este esquema:
            {
                "fechaReunion": "string",
                "horaReunion": "string",
                "lugar": "string",
                "asistentes": ["string"],
                "resumenEjecutivo": "string",
                "temasTratados": ["string"],
                "acuerdosAlcanzados": ["string"],
                "proximosPasos": ["string"],
                "conclusiones": "string"
            }
            `;

            const response = await ai.models.generateContent({
                model: "gemini-1.5-flash",
                contents: [
                    {
                        parts: [
                            { text: prompt },
                            {
                                inlineData: {
                                    mimeType: recording.blob.type || 'audio/webm',
                                    data: audioBase64
                                }
                            }
                        ]
                    }
                ],
                config: {
                    responseMimeType: "application/json"
                }
            });

            const text = response.text;
            if (!text) throw new Error("No se recibió respuesta de la IA");
            const summaryJson = JSON.parse(text);

            setRecordings(prev => 
                prev.map(r => r.id === recording.id ? { ...r, summary: summaryJson } : r)
            );
            setCurrentSummary(summaryJson);
            setEditableSummary(JSON.parse(JSON.stringify(summaryJson)));

        } catch (err: any) {
            console.error("Error generando el resumen con Gemini:", err);
            const errorMsg = err.message || "Error desconocido";
            
            if (errorMsg.includes('AUTH_ERROR') || errorMsg.includes('API_KEY_INVALID') || errorMsg.includes('403') || errorMsg.includes('400') || errorMsg.includes('key not valid')) {
                setIsAuthError(true);
                setError("Error de autenticación: La clave de API de Gemini no es válida o no está configurada. Por favor, asegúrate de haber configurado tu clave en el menú de configuración (icono de engranaje).");
            } else {
                setError(`No se pudo generar el resumen. Detalle: ${errorMsg}`);
            }
        } finally {
            setIsLoadingSummary(false);
            setProcessingStatus("");
        }
    };
    
    const viewSummary = (recording: Recording) => {
        if (recording.summary) {
            setActiveRecording(recording);
            setCurrentSummary(recording.summary);
            setEditableSummary(JSON.parse(JSON.stringify(recording.summary)));
            setIsEditingSummary(false);
        }
    };
    
    const createPDFDoc = (summary: Summary, photo?: string) => {
        const { jsPDF } = window.jspdf;
        const doc = new jsPDF();
        const margin = 15;
        let y = 20;
        const pageHeight = doc.internal.pageSize.height;
        const pageWidth = doc.internal.pageSize.width;
        const wrapWidth = pageWidth - margin * 2;
        
        if (logo) {
            try {
                const img = new Image();
                img.src = logo;
                const logoWidth = 40;
                const logoHeight = (img.height * logoWidth) / img.width;
                doc.addImage(logo, 'PNG', margin, y, logoWidth, logoHeight);
                y += logoHeight + 10;
            } catch (e) {
                console.error("Error al añadir el logo al PDF:", e);
            }
        }

        doc.setFont('helvetica', 'bold');
        doc.setFontSize(22);
        doc.text("Resumen Ejecutivo de la Reunión", pageWidth / 2, y, { align: 'center' });
        y += 15;

        if (photo) {
            try {
                const img = new Image();
                img.src = photo;
                const maxWidth = 100;
                const maxHeight = 80;
                let imgWidth = img.width;
                let imgHeight = img.height;

                if (imgWidth > maxWidth) {
                    imgHeight = (imgHeight * maxWidth) / imgWidth;
                    imgWidth = maxWidth;
                }
                if (imgHeight > maxHeight) {
                    imgWidth = (imgWidth * maxHeight) / imgHeight;
                    imgHeight = maxHeight;
                }

                const xOffset = (pageWidth - imgWidth) / 2;
                
                if (y + imgHeight > pageHeight - 20) {
                    doc.addPage();
                    y = 20;
                }

                doc.addImage(photo, 'JPEG', xOffset, y, imgWidth, imgHeight);
                y += imgHeight + 10;

            } catch(e) {
                 console.error("Error al añadir la foto de asistentes al PDF:", e);
            }
        }

        const addTitle = (text: string) => {
            if (y > pageHeight - 30) {
                doc.addPage();
                y = 20;
            }
            doc.setFont('helvetica', 'bold');
            doc.setFontSize(16);
            doc.text(text, margin, y);
            y += 10;
        };
        
        const addText = (text: string) => {
             if (y > pageHeight - 20) {
                doc.addPage();
                y = 20;
            }
            doc.setFont('helvetica', 'normal');
            doc.setFontSize(11);
            const lines = doc.splitTextToSize(text, wrapWidth);
            doc.text(lines, margin, y);
            y += (lines.length * 5) + 5;
        };

        const addList = (items: string[]) => {
            doc.setFont('helvetica', 'normal');
            doc.setFontSize(11);
            items.forEach(item => {
                 if (y > pageHeight - 20) {
                    doc.addPage();
                    y = 20;
                }
                const lines = doc.splitTextToSize(`- ${item}`, wrapWidth - 5);
                doc.text(lines, margin + 5, y);
                 y += (lines.length * 5);
            });
            y += 5;
        };

        addText(`Fecha: ${summary.fechaReunion}`);
        addText(`Hora: ${summary.horaReunion}`);
        addText(`Lugar: ${summary.lugar}`);
        y += 5;

        addTitle("Asistentes");
        addList(summary.asistentes);
        addTitle("Resumen Ejecutivo");
        addText(summary.resumenEjecutivo);
        addTitle("Temas Tratados");
        addList(summary.temasTratados);
        addTitle("Acuerdos Alcanzados");
        addList(summary.acuerdosAlcanzados);
        addTitle("Próximos Pasos");
        addList(summary.proximosPasos);
        addTitle("Conclusiones");
        addText(summary.conclusiones);

        return doc;
    };

    const downloadSummaryAsPDF = (summary: Summary, photo?: string) => {
        const doc = createPDFDoc(summary, photo);
        doc.save('resumen_reunion.pdf');
    };

    const shareSummaryAsPDF = async (summary: Summary, photo?: string) => {
        const doc = createPDFDoc(summary, photo);
        try {
            const pdfBlob = doc.output('blob');
            const file = new File([pdfBlob], 'resumen_reunion.pdf', {
                type: 'application/pdf',
            });
            await navigator.share({
                title: 'Resumen de Reunión',
                text: `Resumen de la reunión del ${summary.fechaReunion}.`,
                files: [file],
            });
        } catch (error) {
            console.error('Error al compartir el archivo:', error);
        }
    };

    const handleDeleteRecording = (idToDelete: string) => {
        setRecordingToDeleteId(idToDelete);
    };

    const confirmDeleteRecording = () => {
        if (recordingToDeleteId) {
            setRecordings(prev => prev.filter(rec => rec.id !== recordingToDeleteId));
            setRecordingToDeleteId(null);
        }
    };
    
    const cancelDeleteRecording = () => {
        setRecordingToDeleteId(null);
    };

    const handleEditRecording = (recording: Recording) => {
        setEditingRecordingId(recording.id);
        setEditingRecordingData({
            name: recording.name,
            date: recording.date,
            lugar: recording.lugar || ''
        });
    };

    const cancelEditRecording = () => {
        setEditingRecordingId(null);
        setEditingRecordingData({});
    };

    const saveRecordingChanges = () => {
        if (!editingRecordingId) return;
        setRecordings(prev => prev.map(rec => 
            rec.id === editingRecordingId ? { ...rec, ...editingRecordingData } : rec
        ).sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime()));
        cancelEditRecording();
    };

    const handleRecordingDataChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const { name, value } = e.target;
        const currentDate = new Date(editingRecordingData.date || Date.now());

        if (name === 'date') {
            const [year, month, day] = value.split('-').map(Number);
            currentDate.setFullYear(year, month - 1, day);
            setEditingRecordingData(prev => ({ ...prev, date: currentDate }));
        } else if (name === 'time') {
            const [hours, minutes] = value.split(':').map(Number);
            currentDate.setHours(hours, minutes);
            setEditingRecordingData(prev => ({ ...prev, date: currentDate }));
        } else {
            setEditingRecordingData(prev => ({ ...prev, [name]: value }));
        }
    };
    
    const formatDateForInput = (date: Date): string => {
        const d = new Date(date);
        const year = d.getFullYear();
        const month = (d.getMonth() + 1).toString().padStart(2, '0');
        const day = d.getDate().toString().padStart(2, '0');
        return `${year}-${month}-${day}`;
    };
    
    const formatTimeForInput = (date: Date): string => {
        const d = new Date(date);
        const hours = d.getHours().toString().padStart(2, '0');
        const minutes = d.getMinutes().toString().padStart(2, '0');
        return `${hours}:${minutes}`;
    };

    const handleSummaryChange = (field: keyof Summary, value: string | string[]) => {
        if (editableSummary) {
            setEditableSummary({ ...editableSummary, [field]: value });
        }
    };

    const handleArraySummaryChange = (field: keyof Summary, index: number, value: string) => {
        if (editableSummary && Array.isArray(editableSummary[field])) {
            const newArray = [...(editableSummary[field] as string[])];
            newArray[index] = value;
            handleSummaryChange(field, newArray);
        }
    };

    const addArrayItem = (field: keyof Summary) => {
        if (editableSummary && Array.isArray(editableSummary[field])) {
            const newArray = [...(editableSummary[field] as string[]), ""];
            handleSummaryChange(field, newArray);
        }
    };
    
    const removeArrayItem = (field: keyof Summary, index: number) => {
        if (editableSummary && Array.isArray(editableSummary[field])) {
            const newArray = (editableSummary[field] as string[]).filter((_, i) => i !== index);
            handleSummaryChange(field, newArray);
        }
    };
    
    const saveSummaryChanges = () => {
        if (activeRecording) {
            setRecordings(prev => 
                prev.map(rec => 
                    rec.id === activeRecording.id ? { ...rec, summary: editableSummary } : rec
                )
            );
            setCurrentSummary(editableSummary);
        }
        setIsEditingSummary(false);
    };
    
    const cancelSummaryChanges = () => {
        setEditableSummary(currentSummary);
        setIsEditingSummary(false);
    };
    
    const closeModal = () => {
        setCurrentSummary(null);
        setEditableSummary(null);
        setIsEditingSummary(false);
        setActiveRecording(null);
    };

    const handleLogoUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
        const file = e.target.files?.[0];
        if (file) {
            const base64 = await fileToBase64(file);
            setLogo(base64);
            localStorage.setItem('companyLogo', base64);
        }
    };

    const removeLogo = () => {
        setLogo(null);
        localStorage.removeItem('companyLogo');
    };

    const handleInitiatePhotoUpload = (id: string) => {
        setRecordingIdForPhoto(id);
        photoInputRef.current?.click();
    };

    const handlePhotoUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
        const file = e.target.files?.[0];
        if (file && recordingIdForPhoto) {
            const base64 = await fileToBase64(file);
            setRecordings(prev =>
                prev.map(r =>
                    r.id === recordingIdForPhoto ? { ...r, attendeesPhoto: base64 } : r
                )
            );
            setRecordingIdForPhoto(null);
        }
        if (e.target) {
            e.target.value = '';
        }
    };

    const removePhoto = (id: string) => {
        setRecordings(prev =>
            prev.map(r => {
                if (r.id === id) {
                    const { attendeesPhoto, ...rest } = r;
                    return rest as Recording;
                }
                return r;
            })
        );
    };

    const renderSummarySection = (title: string, content: string | string[], fieldName: keyof Summary) => {
        const isArray = Array.isArray(content);
        return (
            <>
                <h3>{title}</h3>
                {isEditingSummary ? (
                    isArray ? (
                        <div className="editable-list">
                            {(content as string[]).map((item, index) => (
                                <div key={index} className="editable-list-item">
                                    <input
                                        type="text"
                                        value={item}
                                        onChange={(e) => handleArraySummaryChange(fieldName, index, e.target.value)}
                                    />
                                    <button onClick={() => removeArrayItem(fieldName, index)}>&times;</button>
                                </div>
                            ))}
                            <button className="add-item-button" onClick={() => addArrayItem(fieldName)}>+ Añadir</button>
                        </div>
                    ) : (
                        <textarea
                            value={content as string}
                            onChange={(e) => handleSummaryChange(fieldName, e.target.value)}
                         />
                    )
                ) : (
                    isArray ? <ul>{content.map((item, index) => <li key={index}>{item}</li>)}</ul> : <p>{content}</p>
                )}
            </>
        );
    };

    return (
        <div className="container">
            <input 
                type="file" 
                accept="image/*" 
                capture="environment" 
                ref={photoInputRef} 
                onChange={handlePhotoUpload} 
                style={{ display: 'none' }} 
            />
            <input 
                type="file" 
                accept="audio/*,video/*,.mp3,.wav,.m4a,.mp4,.ogg,.flac,application/octet-stream" 
                ref={uploadInputRef} 
                onChange={handleFileUpload} 
                style={{ display: 'none' }} 
            />

            <div className="header-row">
                <div className="header-left">
                    <button onClick={() => setShowApiKeyInput(!showApiKeyInput)} className="config-toggle-button" aria-label="Configuración" title="Configuración de API Key">
                        <svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 0 24 24" width="24px" fill="currentColor"><path d="M0 0h24v24H0V0z" fill="none"/><path d="M19.14 12.94c.04-.3.06-.61.06-.94 0-.32-.02-.64-.07-.94l2.03-1.58c.18-.14.23-.41.12-.61l-1.92-3.32c-.12-.22-.37-.29-.59-.22l-2.39.96c-.5-.38-1.03-.7-1.62-.94l-.36-2.54c-.04-.24-.24-.41-.48-.41h-3.84c-.24 0-.43.17-.47.41l-.36 2.54c-.59.24-1.13.57-1.62.94l-2.39-.96c-.22-.08-.47 0-.59.22L2.74 8.87c-.12.21-.08.47.12.61l2.03 1.58c-.05.3-.09.63-.09.94s.02.64.07.94l-2.03 1.58c-.18.14-.23.41-.12.61l1.92 3.32c.12.22.37.29.59.22l2.39-.96c.5.38 1.03.7 1.62.94l.36 2.54c.05.24.24.41.48.41h3.84c.24 0 .44-.17.47-.41l.36-2.54c.59-.24 1.13-.56 1.62-.94l2.39.96c.22.08.47 0 .59-.22l1.92-3.32c.12-.22.07-.47-.12-.61l-2.01-1.58zM12 15.6c-1.98 0-3.6-1.62-3.6-3.6s1.62-3.6 3.6-3.6 3.6 1.62 3.6 3.6-1.62 3.6-3.6 3.6z"/></svg>
                    </button>
                </div>
                <div className="header-right">
                <button onClick={toggleTheme} className="theme-toggle-button" aria-label="Cambiar tema">
                {theme === 'dark' ? (
                    <svg xmlns="http://www.w3.org/2000/svg" enableBackground="new 0 0 24 24" height="24px" viewBox="0 0 24 24" width="24px" fill="currentColor"><rect fill="none" height="24" width="24"/><path d="M12,7c-2.76,0-5,2.24-5,5s2.24,5,5,5s5-2.24,5-5S14.76,7,12,7L12,7z M2,13l2,0c0.03-0.52,0.12-1.03,0.25-1.52L2.6,10.1 C2.22,10.99,2,12,2,13z M20,13c0-1-0.22-1.99-0.6-2.9l-1.65,1.38C17.88,11.97,17.97,12.48,18,13l2,0z M12,5.25L12,5.25 c0.41,0,0.75-0.34,0.75-0.75V2c0-0.41-0.34-0.75-0.75-0.75S11.25,1.59,11.25,2v2.5C11.25,4.91,11.59,5.25,12,5.25z M5.64,6.75 L4.22,5.34C3.83,5.73,3.83,6.36,4.22,6.75l0.01,0.01l1.41,1.41C6.01,7.78,6.64,7.78,7.05,7.38C7.44,6.99,7.44,6.36,7.05,5.96 L5.64,6.75z M18.36,6.75l1.41-1.41c0.39-0.39,0.39-1.02,0-1.41c-0.39-0.39-1.02-0.39-1.41,0l-1.41,1.41c-0.39,0.39-0.39,1.02,0,1.41 C17.34,7.78,17.97,7.78,18.36,6.75z M19.78,17.25l-1.41-1.41c-0.39-0.39-1.02-0.39-1.41,0s-0.39,1.02,0,1.41l1.41,1.41 c0.39,0.39,1.02,0.39,1.41,0C20.17,18.28,20.17,17.64,19.78,17.25z M7.05,18.66c0.39-0.39,0.39-1.02,0-1.41L5.64,15.84 c-0.4-0.39-1.03-0.39-1.42,0c-0.39,0.39-0.39,1.02,0,1.41l1.41,1.41C6.02,19.05,6.65,19.05,7.05,18.66z M12,18.75L12,18.75 c-0.41,0-0.75,0.34-0.75,0.75V22c0,0.41,0.34,0.75,0.75,0.75s0.75-0.34,0.75-0.75v-2.5C12.75,19.09,12.41,18.75,12,18.75z"/></svg>
                ) : (
                    <svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 0 24 24" width="24px" fill="currentColor"><path d="M0 0h24v24H0V0z" fill="none"/><path d="M9.37 5.51C9.19 6.15 9.06 6.82 9.03 7.5c-.02.46.35.84.81.84h4.3c.46 0 .83-.38.81-.84-.03-.68-.16-1.35-.34-1.99-.18-.64-.6-1.21-1.13-1.67-.53-.46-1.16-.7-1.82-.7s-1.29.24-1.82.7c-.53.46-.95 1.03-1.13 1.67zM12 2c-3.31 0-6 2.69-6 6s2.69 6 6 6 6-2.69 6-6-2.69-6-6-6zm-4 6c0-2.21 1.79-4 4-4s4 1.79 4 4c0 .75-.21 1.45-.58 2.05-.17.28-.48.45-.82.45H9.4c-.34 0-.65-.17-.82-.45C8.21 9.45 8 8.75 8 8zm8 7c-1.1 0-2 .9-2 2s.9 2 2 2 2-.9 2-2-.9-2-2-2zM4 15c-1.1 0-2 .9-2 2s.9 2 2 2 2-.9 2-2-.9-2-2-2zM12 15c-1.1 0-2 .9-2 2s.9 2 2 2 2-.9 2-2-.9-2-2-2z"/></svg>
                )}
            </button>
        </div>
    </div>
            <div className="title-container">
                <h1 className="main-title" data-text="GLUCENA">GLUCENA</h1>
                <p className="subtitle">Grabadora de Reuniones AI</p>
            </div>
            {showApiKeyInput && (
                <div className="api-key-config-overlay">
                    <div className="api-key-config-modal">
                        <h3>Configuración de Clave API Gemini</h3>
                        <p>Introduce tu clave de Google AI Studio para habilitar el resumen.</p>
                        <input 
                            type="password" 
                            value={manualApiKey} 
                            onChange={(e) => setManualApiKeyState(e.target.value)} 
                            placeholder="Introduce tu API Key aquí..."
                            className="api-key-input"
                        />
                        <div className="api-key-actions">
                            <button onClick={handleSaveManualKey} className="save-key-button">Guardar Clave</button>
                            <button onClick={() => setShowApiKeyInput(false)} className="cancel-key-button">Cancelar</button>
                        </div>
                        <p className="api-key-help">
                            Puedes obtener una clave gratuita en <a href="https://aistudio.google.com/app/apikey" target="_blank" rel="noopener noreferrer">Google AI Studio</a>.
                        </p>
                    </div>
                </div>
            )}
            <div className="timer-controls">
                <div className="timer">{formatTime(elapsedTime)}</div>
                {isRecording && (
                    <button onClick={handleRestartTimer} className="restart-button" aria-label="Reiniciar contador">
                        <svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 0 24 24" width="24px" fill="currentColor"><path d="M0 0h24v24H0V0z" fill="none"/><path d="M12 5V1L7 6l5 5V7c3.31 0 6 2.69 6 6s-2.69 6-6 6-6-2.69-6-6H4c0 4.42 3.58 8 8 8s8-3.58 8-8-3.58-8-8-8z"/></svg>
                    </button>
                )}
            </div>
            <button
                className={`record-button ${isRecording ? 'recording' : ''}`}
                onClick={isRecording ? handleStopRecording : startRecording}
                aria-label={isRecording ? 'Detener grabación' : 'Iniciar grabación'}
            >
                {isRecording ? <div className="stop-icon"></div> : (
                    <svg viewBox="0 0 24 24">
                        <path d="M12 14c1.66 0 3-1.34 3-3V5c0-1.66-1.34-3-3-3S9 3.34 9 5v6c0 1.66 1.34 3 3 3zm5.3-3c0 3-2.54 5.1-5.3 5.1S6.7 14 6.7 11H5c0 3.41 2.72 6.23 6 6.72V21h2v-3.28c3.28-.49 6-3.31 6-6.72h-1.7z"></path>
                    </svg>
                )}
            </button>
            
            <div style={{display: 'flex', justifyContent: 'center', marginBottom: '30px', marginTop: '-15px'}}>
                <button className="upload-trigger" onClick={() => uploadInputRef.current?.click()}>
                    <svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 0 24 24" width="24px" fill="currentColor"><path d="M0 0h24v24H0V0z" fill="none"/><path d="M9 16h6v-6h4l-7-7-7 7h4v6zm-4 2h14v2H5v-2z"/></svg>
                    Subir Audio
                </button>
            </div>

            <div className="logo-section">
                <h2>Logo para Reportes</h2>
                <div className="logo-controls">
                    {logo ? (
                        <img src={logo} alt="Logo de la empresa" className="logo-preview" />
                    ) : (
                        <div className="logo-placeholder">Sin logo</div>
                    )}
                    <input type="file" accept="image/*" ref={fileInputRef} onChange={handleLogoUpload} style={{ display: 'none' }} />
                    <button className="action-button" onClick={() => fileInputRef.current?.click()}>
                        <svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 0 24 24" width="24px" fill="currentColor"><path d="M0 0h24v24H0V0z" fill="none"/><path d="M9 16h6v-6h4l-7-7-7 7h4v6zm-4 2h14v2H5v-2z"/></svg>
                        {logo ? 'Cambiar Logo' : 'Subir Logo'}
                    </button>
                    {logo && <button className="action-button danger" onClick={removeLogo}>
                        <svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 0 24 24" width="24px" fill="currentColor"><path d="M0 0h24v24H0V0z" fill="none"/><path d="M6 19c0 1.1.9 2 2 2h8c1.1 0 2-.9 2-2V7H6v12zM19 4h-3.5l-1-1h-5l-1 1H5v2h14V4z"/></svg>
                        Quitar
                    </button>}
                </div>
            </div>

            {error && !isLoadingSummary && (
                <div className="error-container">
                    <p className="error-text">{error}</p>
                    {isAuthError && (
                        <button className="action-button primary" onClick={handleConfigureKey}>
                            Configurar Clave
                        </button>
                    )}
                </div>
            )}



            <div className="history-section">
                <h2>Historial de Grabaciones</h2>
                <ul className="recordings-list">
                    {recordings.map((rec) => (
                        <li key={rec.id} className="recording-item">
                            {editingRecordingId === rec.id ? (
                                <div className="recording-edit-form">
                                    <input type="text" name="name" value={editingRecordingData.name} onChange={handleRecordingDataChange} placeholder="Nombre de la grabación" />
                                    <div className="date-time-inputs">
                                        <input type="date" name="date" value={formatDateForInput(editingRecordingData.date as Date)} onChange={handleRecordingDataChange} />
                                        <input type="time" name="time" value={formatTimeForInput(editingRecordingData.date as Date)} onChange={handleRecordingDataChange} />
                                    </div>
                                    <input type="text" name="lugar" value={editingRecordingData.lugar} onChange={handleRecordingDataChange} placeholder="Lugar (ej. Oficina, Zoom)" />
                                    <div className="recording-actions">
                                        <button className="action-button" onClick={cancelEditRecording}>
                                            <svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 0 24 24" width="24px" fill="currentColor"><path d="M0 0h24v24H0V0z" fill="none"/><path d="M19 6.41L17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12 19 6.41z"/></svg>
                                            Cancelar
                                        </button>
                                        <button className="action-button success" onClick={saveRecordingChanges}>
                                            <svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 0 24 24" width="24px" fill="currentColor"><path d="M0 0h24v24H0V0z" fill="none"/><path d="M9 16.2L4.8 12l-1.4 1.4L9 19 21 7l-1.4-1.4L9 16.2z"/></svg>
                                            Guardar
                                        </button>
                                    </div>
                                </div>
                            ) : (
                                <>
                                    <div className="recording-main-content">
                                        {rec.attendeesPhoto && (
                                            <img src={rec.attendeesPhoto} alt="Foto de asistentes" className="attendees-photo-thumbnail" />
                                        )}
                                        <div className="recording-info">
                                            <div>
                                                <strong>{rec.name}</strong>
                                                <small>{rec.lugar}</small>
                                            </div>
                                            <span>{new Date(rec.date).toLocaleString('es-ES', { dateStyle: 'short', timeStyle: 'short' })} {rec.duration > 0 ? `- ${formatTime(rec.duration)}` : ''}</span>
                                        </div>
                                    </div>
                                    <audio src={rec.blobUrl} controls />
                                    <div className="recording-actions">
                                        <button className="action-button" onClick={() => handleInitiatePhotoUpload(rec.id)}>
                                            <svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 0 24 24" width="24px" fill="currentColor"><path d="M0 0h24v24H0V0z" fill="none"/><path d="M21 19V5c0-1.1-.9-2-2-2H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2zM8.5 13.5l2.5 3.01L14.5 12l4.5 6H5l3.5-4.5z"/></svg>
                                            {rec.attendeesPhoto ? 'Cambiar Foto' : 'Añadir Foto'}
                                        </button>
                                        {rec.attendeesPhoto && <button className="action-button danger" onClick={() => removePhoto(rec.id)}>
                                            <svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 0 24 24" width="24px" fill="currentColor"><path d="M0 0h24v24H0V0z" fill="none"/><path d="M21.12 2.88L2.88 21.12 1.46 19.71 19.71 1.46 21.12 2.88zM10.5 12.5l-1-1-6 6V20c0 1.1.9 2 2 2h8.5l-4-4zM21 6.5l-4-4-1.21 1.21 4 4L21 6.5zM19 10.4l-4-4L6.17 15.23l4 4L19 10.4zM3 5.83V5c0-1.1.9-2 2-2h9.17l-2-2H5c-2.21 0-4 1.79-4 4v14c0 1.42.74 2.67 1.84 3.36L3 21.17V5.83z"/></svg>
                                            Quitar Foto
                                        </button>}
                                        <button className="action-button" onClick={() => handleEditRecording(rec)}>
                                            <svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 0 24 24" width="24px" fill="currentColor"><path d="M0 0h24v24H0V0z" fill="none"/><path d="M3 17.25V21h3.75L17.81 9.94l-3.75-3.75L3 17.25zM20.71 7.04c.39-.39.39-1.02 0-1.41l-2.34-2.34c-.39-.39-1.02-.39-1.41 0l-1.83 1.83 3.75 3.75 1.83-1.83z"/></svg>
                                            Editar
                                        </button>
                                        {rec.summary ? (
                                             <button 
                                                className="action-button view-summary"
                                                onClick={() => viewSummary(rec)}
                                                title="Ver Resumen"
                                            >
                                                <svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 0 24 24" width="24px"><path d="M0 0h24v24H0V0z" fill="none"/><path d="M14 2H6c-1.1 0-1.99.9-1.99 2L4 20c0 1.1.89 2 1.99 2H18c1.1 0 2-.9 2-2V8l-6-6zM16 18H8v-2h8v2zm0-4H8v-2h8v2zm-3-5V3.5L18.5 9H13z"/></svg>
                                                Ver Resumen
                                            </button>
                                        ) : (
                                            <button 
                                                className="action-button primary" 
                                                onClick={() => generateSummary(rec)}
                                                disabled={isLoadingSummary}
                                            >
                                                {isLoadingSummary && activeRecording?.id === rec.id ? 'Generando...' : 
                                                <>
                                                    <svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 0 24 24" width="24px" fill="currentColor"><g><rect fill="none" height="24" width="24"/></g><g><g><path d="M19,9l1.25-2.75L23,5l-2.75-1.25L19,1l-1.25,2.75L15,5l2.75,1.25L19,9z M11.5,9.5L9,4L6.5,9.5L1,12l5.5,2.5L9,20l2.5-5.5 L17,12L11.5,9.5z"/></g></g></svg>
                                                    Generar Resumen
                                                </>
                                                }
                                            </button>
                                        )}
                                        <button className="action-button danger" onClick={() => handleDeleteRecording(rec.id)}>
                                            <svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 0 24 24" width="24px" fill="currentColor"><path d="M0 0h24v24H0V0z" fill="none"/><path d="M6 19c0 1.1.9 2 2 2h8c1.1 0 2-.9 2-2V7H6v12zM19 4h-3.5l-1-1h-5l-1 1H5v2h14V4z"/></svg>
                                            Eliminar
                                        </button>
                                    </div>
                                </>
                            )}
                        </li>
                    ))}
                </ul>
            </div>

            {(isLoadingSummary || currentSummary) && (
                <div className="modal-overlay" onClick={closeModal}>
                    <div className="modal-content" onClick={(e) => e.stopPropagation()}>
                        <button className="close-button" onClick={closeModal}>&times;</button>
                        {isLoadingSummary && (
                            <div style={{ textAlign: 'center', padding: '20px' }}>
                                <p className="loading-text" style={{ fontSize: '1.1rem', marginBottom: '10px' }}>{processingStatus || "Cargando..."}</p>
                                <div style={{ 
                                    width: '40px', 
                                    height: '40px', 
                                    border: '4px solid rgba(0, 123, 255, 0.3)', 
                                    borderTop: '4px solid var(--primary-color)', 
                                    borderRadius: '50%', 
                                    animation: 'spin 1s linear infinite',
                                    margin: '0 auto' 
                                }}></div>
                                <style>{`@keyframes spin { 0% { transform: rotate(0deg); } 100% { transform: rotate(360deg); } }`}</style>
                            </div>
                        )}
                        {currentSummary && editableSummary && !isLoadingSummary && (
                            <>
                                <div className="modal-header">
                                    <h2>Resumen Ejecutivo</h2>
                                    <div className="header-actions">
                                        {canShare && (
                                            <button className="action-button" onClick={() => shareSummaryAsPDF(currentSummary, activeRecording?.attendeesPhoto)} title="Compartir">
                                                <svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 0 24 24" width="24px"><path d="M0 0h24v24H0V0z" fill="none"/><path d="M18 16.08c-.76 0-1.44.3-1.96.77L8.91 12.7c.05-.23.09-.46.09-.7s-.04-.47-.09-.7l7.05-4.11c.54.5 1.25.81 2.04.81 1.66 0 3-1.34 3-3s-1.34-3-3-3-3 1.34-3 3c0 .24.04.47.09.7L8.04 9.81C7.5 9.31 6.79 9 6 9c-1.66 0-3 1.34-3 3s1.34 3 3 3c.79 0 1.5-.31 2.04-.81l7.12 4.16c-.05.21-.08.43-.08.65 0 1.66 1.34 3 3 3s3-1.34 3-3-1.34-3-3-3z"/></svg>
                                            </button>
                                        )}
                                        <button className="action-button" onClick={() => downloadSummaryAsPDF(currentSummary, activeRecording?.attendeesPhoto)} title="Descargar como PDF">
                                            <svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 0 24 24" width="24px"><path d="M0 0h24v24H0V0z" fill="none"/><path d="M19 9h-4V3H9v6H5l7 7 7-7zM5 18v2h14v-2H5z"/></svg>
                                        </button>
                                        {!isEditingSummary ? (
                                            <button className="action-button" onClick={() => setIsEditingSummary(true)}>
                                                <svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 0 24 24" width="24px" fill="currentColor"><path d="M0 0h24v24H0V0z" fill="none"/><path d="M3 17.25V21h3.75L17.81 9.94l-3.75-3.75L3 17.25zM20.71 7.04c.39-.39.39-1.02 0-1.41l-2.34-2.34c-.39-.39-1.02-.39-1.41 0l-1.83 1.83 3.75 3.75 1.83-1.83z"/></svg>
                                                Editar
                                            </button>
                                        ) : (
                                            <div className="editing-actions">
                                                <button className="action-button" onClick={cancelSummaryChanges}>
                                                    <svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 0 24 24" width="24px" fill="currentColor"><path d="M0 0h24v24H0V0z" fill="none"/><path d="M19 6.41L17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12 19 6.41z"/></svg>
                                                    Cancelar
                                                </button>
                                                <button className="action-button success" onClick={saveSummaryChanges}>
                                                    <svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 0 24 24" width="24px" fill="currentColor"><path d="M0 0h24v24H0V0z" fill="none"/><path d="M9 16.2L4.8 12l-1.4 1.4L9 19 21 7l-1.4-1.4L9 16.2z"/></svg>
                                                    Guardar
                                                </button>
                                            </div>
                                        )}
                                    </div>
                                </div>
                                
                                <div className="summary-details">
                                    <div className="summary-field">
                                        <strong>Fecha:</strong>
                                        {isEditingSummary ? (
                                            <input type="text" value={editableSummary.fechaReunion} onChange={(e) => handleSummaryChange('fechaReunion', e.target.value)} />
                                        ) : (
                                            <span>{currentSummary.fechaReunion}</span>
                                        )}
                                    </div>
                                     <div className="summary-field">
                                        <strong>Hora:</strong>
                                        {isEditingSummary ? (
                                            <input type="text" value={editableSummary.horaReunion} onChange={(e) => handleSummaryChange('horaReunion', e.target.value)} />
                                        ) : (
                                            <span>{currentSummary.horaReunion}</span>
                                        )}
                                    </div>
                                    <div className="summary-field">
                                        <strong>Lugar:</strong>
                                        {isEditingSummary ? (
                                            <input type="text" value={editableSummary.lugar} onChange={(e) => handleSummaryChange('lugar', e.target.value)} />
                                        ) : (
                                            <span>{currentSummary.lugar}</span>
                                        )}
                                    </div>
                                </div>
                                
                                {renderSummarySection("Asistentes", isEditingSummary ? editableSummary.asistentes : currentSummary.asistentes, 'asistentes')}
                                {renderSummarySection("Resumen Ejecutivo", isEditingSummary ? editableSummary.resumenEjecutivo : currentSummary.resumenEjecutivo, 'resumenEjecutivo')}
                                {renderSummarySection("Temas Tratados", isEditingSummary ? editableSummary.temasTratados : currentSummary.temasTratados, 'temasTratados')}
                                {renderSummarySection("Acuerdos Alcanzados", isEditingSummary ? editableSummary.acuerdosAlcanzados : currentSummary.acuerdosAlcanzados, 'acuerdosAlcanzados')}
                                {renderSummarySection("Próximos Pasos", isEditingSummary ? editableSummary.proximosPasos : currentSummary.proximosPasos, 'proximosPasos')}
                                {renderSummarySection("Conclusiones", isEditingSummary ? editableSummary.conclusiones : currentSummary.conclusiones, 'conclusiones')}
                            </>
                        )}
                    </div>
                </div>
            )}
            
            {recordingToDeleteId && (
                <div className="modal-overlay">
                    <div className="modal-content confirmation-modal-content">
                        <h3>Confirmar Eliminación</h3>
                        <p>
                            ¿Estás seguro de que quieres eliminar esta grabación? 
                            Todos los datos asociados se perderán permanentemente.
                        </p>
                        <div className="confirmation-actions">
                            <button className="action-button" onClick={cancelDeleteRecording}>
                                <svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 0 24 24" width="24px" fill="currentColor"><path d="M0 0h24v24H0V0z" fill="none"/><path d="M19 6.41L17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12 19 6.41z"/></svg>
                                Cancelar
                            </button>
                            <button className="action-button danger" onClick={confirmDeleteRecording}>
                                <svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 0 24 24" width="24px" fill="currentColor"><path d="M0 0h24v24H0V0z" fill="none"/><path d="M6 19c0 1.1.9 2 2 2h8c1.1 0 2-.9 2-2V7H6v12zM19 4h-3.5l-1-1h-5l-1 1H5v2h14V4z"/></svg>
                                Eliminar
                            </button>
                        </div>
                    </div>
                </div>
            )}
            <div style={{ textAlign: 'center', fontSize: '10px', opacity: 0.3, marginTop: '20px', paddingBottom: '10px' }}>
                v1.0.1 - 2026-03-19 15:33
            </div>
        </div>
    );
};

const root = ReactDOM.createRoot(document.getElementById('root')!);
root.render(<React.StrictMode><App /></React.StrictMode>);